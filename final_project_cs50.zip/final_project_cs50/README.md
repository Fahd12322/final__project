# CRUDS
#### Video Demo: <https://www.youtube.com/watch?v=SbnnV-ZK2XQ>
#### Description:
Hi, it's my final project in this course.
The project is very simple and it is about managing products to calculate your daily bills.

You can put the product name first, and then put the product price.
There are non-compulsory additions, which are as follows...
1- Taxes.
2- Advertisements.
3 - discount
The total will appear to you from the right (it will change to green if the numbers are entered directly).

After adding the product, it will be stored below.
And you can no longer search for the product by putting a letter or the name of the product.
You can also modify or delete the product.
You can also delete all products in just one button.

That was everything, thanks